# Coordinate Brush

###### *Contributions by:  nicovain, pmurph0305*

This Brush displays the cell coordinates it is targeting in the SceneView. Use this as an example to create brushes which have extra visualization features when painting onto a Tilemap.

![Scene View with Coordinate Brush](images/CoordinateBrush.png)